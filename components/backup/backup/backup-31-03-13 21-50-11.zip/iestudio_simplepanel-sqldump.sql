#
# MySQL database dump
# Created by MySQL_Backup class, ver. 1.0.0
#
# Host: localhost
# Generated: Mar 31, 2013 at 21:50
# MySQL version: 5.1.68-cll
# PHP version: 5.3.18
#
# Database: `iestudio_simplepanel`
#


#
# Table structure for table `backup`
#

DROP TABLE IF EXISTS `backup`;
CREATE TABLE `backup` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `fname` varchar(250) DEFAULT NULL,
  `dte` datetime DEFAULT NULL,
  `sug` int(1) DEFAULT NULL,
  `hash` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

#
# Dumping data for table `backup`
#

INSERT INTO backup VALUES ('26', 'backup-31-03-13 21-50-06.zip', '2013-03-31 21:50:06', '1', 'fa60d2cfa60550dc45fc4baeab503afe');
INSERT INTO backup VALUES ('25', 'backup-31-03-13 21-49-48.zip', '2013-03-31 21:49:48', '1', '8a8347a75578274377388d21fed99296');
INSERT INTO backup VALUES ('23', 'backup-31-03-13 21-46-03.zip', '2013-03-31 21:46:03', '0', '5ea508fa9020cae2afb18d5f10d258c5');
INSERT INTO backup VALUES ('22', 'backup-31-03-13 21-45-50.zip', '2013-03-31 21:45:50', '0', '02d170b5818b29e7741be195c769fa91');
INSERT INTO backup VALUES ('21', 'backup-31-03-13 21-45-07.zip', '2013-03-31 21:45:07', '0', 'e13a100849f177403769660f7cdfca51');


#
# Table structure for table `content`
#

DROP TABLE IF EXISTS `content`;
CREATE TABLE `content` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `father` int(10) DEFAULT NULL,
  `root` varchar(250) DEFAULT NULL,
  `ttl` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `body` blob,
  `keyword` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `title` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `description` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `sug` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;

#
# Dumping data for table `content`
#

INSERT INTO content VALUES ('0', '-1', 'Main', 'Main', '<p><br />טקסט לדוגמא&nbsp;&nbsp; עריכה דרך פאנל ניהול</p>', '????', '?????', '?????', '0');
INSERT INTO content VALUES ('1', '0', 'projects', '????????', '&lt;p&gt;uhuhiujiuh uhu&lt;img src=\\&quot;/user_upload/21405c4a5898f26a7cd0cefbc1bb6dd3.jpg\\&quot; alt=\\&quot;\\&quot; /&gt;dadasdasdsdas&lt;/p&gt;', '', '', '', '0');
INSERT INTO content VALUES ('21', '0', '3', '3', '', '', '', '', '0');
INSERT INTO content VALUES ('7', '1', 'new cat', '???', '<p>123123</p>', '', '', '', '0');
INSERT INTO content VALUES ('8', '7', 'dikan', '????? ?????', '&lt;p&gt;0909&lt;/p&gt;', '', ',nm.l', '', '0');
INSERT INTO content VALUES ('75', '74', '2', '12', '', '', '', '', '0');
INSERT INTO content VALUES ('68', '30', 'dsa', 'testy', '', '', '', '', '0');
INSERT INTO content VALUES ('69', '53', 'sdfsfs', 'dssdf', '', '', '', '', '0');
INSERT INTO content VALUES ('23', '21', '5', '534', '&lt;p&gt;fghfh&lt;/p&gt;
&lt;p&gt;fg&lt;/p&gt;
&lt;p&gt;h&lt;/p&gt;
&lt;p&gt;fg&lt;/p&gt;
&lt;p&gt;hfg&lt;img src=\\&quot;/user_upload/5e9d70de22eefbf64867d1de85023b53.png\\&quot; alt=\\&quot;\\&quot; width=\\&quot;902\\&quot; height=\\&quot;383\\&quot; /&gt;&lt;/p&gt;', '', '', '', '0');
INSERT INTO content VALUES ('24', '21', 'das', 'das', '', '', '', '', '0');
INSERT INTO content VALUES ('57', '31', 'gfdgfgd', 'fgdf', '&lt;p&gt;fdsfsdfsdfsd&lt;/p&gt;', '', '', '', '0');
INSERT INTO content VALUES ('27', '24', 'dasda', 'dsad', '', '', '', '', '0');
INSERT INTO content VALUES ('59', '23', 'ijioj', 'ijjoo', '', '', '', '', '0');
INSERT INTO content VALUES ('30', '1', 'dsf', 'sdffsdf', '', '', '', '', '0');
INSERT INTO content VALUES ('31', '0', 'gd', 'vgbfdg', '', '', '', '', '0');
INSERT INTO content VALUES ('56', '55', 'dada', 'dda', '', '', '', '', '0');
INSERT INTO content VALUES ('34', '23', 'fhg', 'hgf', '', '', '', '', '0');
INSERT INTO content VALUES ('55', '53', 'dadad', 'da', '', '', '', '', '0');
INSERT INTO content VALUES ('53', '0', 'neww', '????? ????', '', '', '', '', '0');
INSERT INTO content VALUES ('54', '53', 'da', 'da', '', '', '', '', '0');
INSERT INTO content VALUES ('60', '31', 'cxvx', 'cv', '', '', '', '', '0');
INSERT INTO content VALUES ('61', '31', 'DA', 'ASDA', '', '', '', '', '0');
INSERT INTO content VALUES ('65', '57', 'das', 'dsa', '', '', '', '', '0');
INSERT INTO content VALUES ('74', '0', 'FSDFDSFS', 'DFSDF', '', '', '', '', '0');


#
# Table structure for table `log`
#

DROP TABLE IF EXISTS `log`;
CREATE TABLE `log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `msg` blob,
  `dte` datetime DEFAULT NULL,
  `calander` int(1) DEFAULT '0',
  `user` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

#
# Dumping data for table `log`
#

INSERT INTO log VALUES ('1', 'Article -פרויקטים - was edited', '2013-03-30 13:24:37', '0', '1');
INSERT INTO log VALUES ('2', 'New article was added - בדיקה ', '2013-03-30 13:24:55', '1', '1');
INSERT INTO log VALUES ('3', 'New article was added - das ', '2013-03-30 13:25:17', '1', '1');
INSERT INTO log VALUES ('4', 'New article was added - dsadasd ', '2013-03-30 13:25:23', '1', '1');
INSERT INTO log VALUES ('5', 'Article was just deleted id - 70 ', '2013-03-30 13:25:33', '1', '1');
INSERT INTO log VALUES ('6', 'Article was just deleted id - 71 ', '2013-03-30 13:25:38', '1', '1');
INSERT INTO log VALUES ('7', 'Article was just deleted id - 72 ', '2013-03-30 13:25:41', '1', '1');
INSERT INTO log VALUES ('8', 'Article was just deleted id - 67 ', '2013-03-30 22:48:29', '1', '1');
INSERT INTO log VALUES ('9', 'new User fdad was registered', '2013-03-31 14:06:51', '0', '42');
INSERT INTO log VALUES ('10', 'User 42 was Deleted By:saoron', '2013-03-31 14:07:02', '0', '1');
INSERT INTO log VALUES ('11', 'User 1 was Deleted By:saoron', '2013-03-31 14:07:31', '0', '1');
INSERT INTO log VALUES ('12', 'new User saoron was registered', '2013-03-31 14:07:45', '0', '43');
INSERT INTO log VALUES ('13', 'new User fdsfsd was registered', '2013-03-31 14:13:01', '0', '44');
INSERT INTO log VALUES ('14', 'User 44 was Deleted By:saoron', '2013-03-31 14:13:14', '0', '1');
INSERT INTO log VALUES ('15', 'new User das was registered', '2013-03-31 14:16:09', '0', '45');
INSERT INTO log VALUES ('16', 'User 45 was Deleted By:saoron', '2013-03-31 14:17:28', '0', '1');
INSERT INTO log VALUES ('17', 'User 45 was Deleted By:saoron', '2013-03-31 14:17:32', '0', '1');
INSERT INTO log VALUES ('18', 'User 45 was Deleted By:saoron', '2013-03-31 14:18:03', '0', '1');
INSERT INTO log VALUES ('19', 'User 45 was Deleted By:saoron', '2013-03-31 14:18:48', '0', '1');
INSERT INTO log VALUES ('20', 'new User demo was registered', '2013-03-31 14:19:13', '0', '46');
INSERT INTO log VALUES ('21', 'New article was added - דג ', '2013-03-31 14:35:44', '1', '1');
INSERT INTO log VALUES ('22', 'New article was added - DFSDF ', '2013-03-31 14:36:30', '1', '1');
INSERT INTO log VALUES ('23', 'Article was just deleted id - 73 ', '2013-03-31 14:36:39', '1', '1');
INSERT INTO log VALUES ('24', 'New article was added - 12 ', '2013-03-31 16:52:06', '1', '41');
INSERT INTO log VALUES ('25', 'Backup from  2013-03-31 21:34:52-deleted By:saoron', '2013-03-31 21:36:03', '0', '1');
INSERT INTO log VALUES ('26', 'Full Backup was created ', '2013-03-31 21:42:36', '0', '0');
INSERT INTO log VALUES ('27', 'Full Backup was created ', '2013-03-31 21:43:37', '0', '0');
INSERT INTO log VALUES ('28', 'Backup from  2013-03-31 21:43:37-deleted By:saoron', '2013-03-31 21:43:47', '0', '1');
INSERT INTO log VALUES ('29', 'Backup from  2013-03-31 21:42:36-deleted By:saoron', '2013-03-31 21:43:49', '0', '1');
INSERT INTO log VALUES ('30', 'Full Backup was created ', '2013-03-31 21:44:40', '0', '0');
INSERT INTO log VALUES ('31', 'Full Backup was created ', '2013-03-31 21:45:02', '0', '0');
INSERT INTO log VALUES ('32', 'Backup from  2013-03-31 21:45:02-deleted By:saoron', '2013-03-31 21:45:04', '0', '1');
INSERT INTO log VALUES ('33', 'Backup from  2013-03-31 21:44:40-deleted By:saoron', '2013-03-31 21:45:06', '0', '1');
INSERT INTO log VALUES ('34', 'Full Backup was created ', '2013-03-31 21:45:07', '0', '0');
INSERT INTO log VALUES ('35', 'Full Backup was created ', '2013-03-31 21:45:50', '0', '0');
INSERT INTO log VALUES ('36', 'Full Backup was created ', '2013-03-31 21:46:03', '0', '0');
INSERT INTO log VALUES ('37', 'Full Backup was created ', '2013-03-31 21:49:44', '0', '0');
INSERT INTO log VALUES ('38', 'Backup from  2013-03-31 21:49:44-deleted By:saoron', '2013-03-31 21:49:47', '0', '1');
INSERT INTO log VALUES ('39', 'Full Backup was created ', '2013-03-31 21:49:48', '0', '0');
INSERT INTO log VALUES ('40', 'Full Backup was created ', '2013-03-31 21:50:06', '0', '0');


#
# Table structure for table `users`
#

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(7) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(35) NOT NULL,
  `email` varchar(35) NOT NULL,
  `activated` int(1) NOT NULL DEFAULT '0',
  `confirmation` varchar(35) NOT NULL,
  `reg_date` int(11) NOT NULL,
  `last_login` int(11) NOT NULL DEFAULT '0',
  `group_id` int(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

#
# Dumping data for table `users`
#

INSERT INTO users VALUES ('1', 'saoron', '1643f7cac4c155ffef3f93922c87cf71', 'saoron@gmail.com', '1', '', '1364728065', '1364749866', '1');
INSERT INTO users VALUES ('46', 'demo', 'e28ba8c5489f850e86ba48ea2b964801', 'das@dsa.com', '1', '', '1364728753', '0', '1');
INSERT INTO users VALUES ('41', 'guest', 'c1c6ac76443bbe4dcacfaafa96b42a8e', 'ghvfvgh@fg.com', '1', '', '1364727795', '1364731359', '1');


#
# Table structure for table `usersdat`
#

DROP TABLE IF EXISTS `usersdat`;
CREATE TABLE `usersdat` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) DEFAULT NULL,
  `faname` varchar(32) DEFAULT NULL,
  `adress` varchar(125) DEFAULT NULL,
  `img` blob,
  `phone` varchar(25) DEFAULT NULL,
  `web` blob,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=144 DEFAULT CHARSET=utf8;

#
# Dumping data for table `usersdat`
#

INSERT INTO usersdat VALUES ('46', '', '', '', '', '', '');
INSERT INTO usersdat VALUES ('1', '', '', '', '', '', '');
INSERT INTO usersdat VALUES ('41', '', '', '', '', '', '');


#
# Table structure for table `visitors_table`
#

DROP TABLE IF EXISTS `visitors_table`;
CREATE TABLE `visitors_table` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `visitor_ip` varchar(32) DEFAULT NULL,
  `visitor_browser` varchar(255) DEFAULT NULL,
  `visitor_hour` smallint(2) NOT NULL DEFAULT '0',
  `visitor_minute` smallint(2) NOT NULL DEFAULT '0',
  `visitor_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `visitor_refferer` varchar(255) DEFAULT NULL,
  `visitor_page` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1072 DEFAULT CHARSET=latin1;

#
# Dumping data for table `visitors_table`
#

INSERT INTO visitors_table VALUES ('470', '82.81.204.24', 'Chrome', '17', '47', '2013-03-30 17:47:55', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('469', '82.81.204.24', 'Chrome', '17', '47', '2013-03-30 17:47:54', 'http://simplepanel.co.il/components/users/edit.php?id=39', '/index.php');
INSERT INTO visitors_table VALUES ('468', '82.81.204.24', 'Chrome', '17', '47', '2013-03-30 17:47:53', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('467', '82.81.204.24', 'Chrome', '17', '47', '2013-03-30 17:47:35', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('465', '82.81.204.24', 'Chrome', '17', '46', '2013-03-30 17:46:53', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('466', '82.81.204.24', 'Chrome', '17', '47', '2013-03-30 17:47:31', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('464', '82.81.204.24', 'Chrome', '17', '46', '2013-03-30 17:46:30', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('463', '82.81.204.24', 'Chrome', '17', '46', '2013-03-30 17:46:13', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('461', '82.81.204.24', 'Chrome', '17', '45', '2013-03-30 17:45:29', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('462', '82.81.204.24', 'Chrome', '17', '45', '2013-03-30 17:45:45', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('460', '82.81.204.24', 'Chrome', '17', '45', '2013-03-30 17:45:23', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('459', '82.81.204.24', 'Chrome', '17', '43', '2013-03-30 17:43:43', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('457', '82.81.204.24', 'Chrome', '17', '43', '2013-03-30 17:43:03', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('458', '82.81.204.24', 'Chrome', '17', '43', '2013-03-30 17:43:33', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('456', '82.81.204.24', 'Chrome', '17', '42', '2013-03-30 17:42:33', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('455', '82.81.204.24', 'Chrome', '17', '42', '2013-03-30 17:42:06', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('453', '82.81.204.24', 'Chrome', '17', '40', '2013-03-30 17:40:55', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('454', '82.81.204.24', 'Chrome', '17', '41', '2013-03-30 17:41:02', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('452', '82.81.204.24', 'Chrome', '17', '40', '2013-03-30 17:40:52', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('451', '82.81.204.24', 'Chrome', '17', '40', '2013-03-30 17:40:38', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('449', '82.81.204.24', 'Chrome', '17', '39', '2013-03-30 17:39:02', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('450', '82.81.204.24', 'Chrome', '17', '40', '2013-03-30 17:40:34', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('430', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:04', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('431', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:25', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('432', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:32', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('433', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:35', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('434', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:38', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('435', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:12', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('436', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:14', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('437', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:15', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('438', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:25', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('439', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:27', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('440', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:28', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('441', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:51', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('442', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:53', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('443', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:55', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('444', '82.81.204.24', 'Chrome', '17', '28', '2013-03-30 17:28:59', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('445', '82.81.204.24', 'Chrome', '17', '37', '2013-03-30 17:37:37', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('446', '82.81.204.24', 'Chrome', '17', '37', '2013-03-30 17:37:42', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('447', '82.81.204.24', 'Chrome', '17', '38', '2013-03-30 17:38:37', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('448', '82.81.204.24', 'Chrome', '17', '38', '2013-03-30 17:38:41', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('429', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:03', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('428', '82.81.204.24', 'Chrome', '17', '27', '2013-03-30 17:27:01', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('411', '82.81.204.24', 'Chrome', '17', '20', '2013-03-30 17:20:36', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('412', '82.81.204.24', 'Chrome', '17', '22', '2013-03-30 17:22:30', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('413', '82.81.204.24', 'Chrome', '17', '24', '2013-03-30 17:24:57', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('414', '82.81.204.24', 'Chrome', '17', '25', '2013-03-30 17:25:03', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('415', '82.81.204.24', 'Chrome', '17', '25', '2013-03-30 17:25:07', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('416', '82.81.204.24', 'Chrome', '17', '25', '2013-03-30 17:25:20', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('417', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:21', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('418', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:28', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('419', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:38', 'http://simplepanel.co.il/components/users/edit.php?id=39', '/index.php');
INSERT INTO visitors_table VALUES ('420', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:39', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('421', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:41', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('422', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:47', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('423', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:48', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('424', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:50', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('425', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:55', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('426', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:57', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('427', '82.81.204.24', 'Chrome', '17', '26', '2013-03-30 17:26:59', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('240', '82.81.204.24', 'Chrome', '17', '13', '2013-03-29 17:13:30', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('241', '82.81.204.24', 'MSIE', '17', '13', '2013-03-26 17:13:33', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('242', '82.81.204.24', 'MSIE', '17', '13', '2013-03-29 17:13:36', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('243', '82.81.204.24', 'MSIE', '17', '13', '2013-03-29 17:13:38', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('244', '82.81.204.24', 'Chrome', '17', '13', '2013-03-29 17:13:39', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('245', '82.81.204.24', 'Safari', '17', '14', '2013-03-29 17:14:40', '', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('246', '82.81.204.24', 'Safari', '17', '14', '2013-03-29 17:14:46', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('247', '82.81.204.24', 'Safari', '17', '14', '2013-03-29 17:14:48', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('248', '82.81.204.24', 'Chrome', '17', '16', '2013-03-29 17:16:22', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('249', '82.81.204.24', 'Chrome', '17', '17', '2013-03-29 17:17:29', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('250', '82.81.204.24', 'Chrome', '17', '18', '2013-03-29 17:18:09', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('251', '82.81.204.24', 'Chrome', '17', '18', '2013-03-29 17:18:10', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('252', '82.81.204.24', 'Chrome', '17', '19', '2013-03-29 17:19:18', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('253', '82.81.204.24', 'Chrome', '17', '20', '2013-03-29 17:20:13', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('254', '82.81.204.24', 'Chrome', '17', '21', '2013-03-29 17:21:37', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('255', '82.81.204.24', 'Chrome', '17', '21', '2013-03-28 17:21:57', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('256', '82.81.204.24', 'Chrome', '17', '24', '2013-03-28 17:24:30', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('257', '82.81.204.24', 'Chrome', '17', '24', '2013-03-28 17:24:40', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('258', '82.81.204.24', 'Chrome', '17', '26', '2013-03-29 17:26:15', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('259', '82.81.204.24', 'Chrome', '17', '29', '2013-03-28 17:29:00', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('260', '82.81.204.24', 'Chrome', '17', '31', '2013-03-29 17:31:08', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('261', '82.81.204.24', 'Chrome', '17', '31', '2013-03-26 17:31:31', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('262', '82.81.204.24', 'Chrome', '17', '32', '2013-03-29 17:32:21', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('263', '82.81.204.24', 'Chrome', '17', '33', '2013-03-29 17:33:21', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('264', '82.81.204.24', 'Chrome', '17', '34', '2013-03-26 17:34:52', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('265', '82.81.204.24', 'Chrome', '17', '35', '2013-03-27 17:35:06', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('266', '82.81.204.24', 'Chrome', '17', '35', '2013-03-29 17:35:50', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('267', '82.81.204.24', 'Chrome', '17', '36', '2013-03-29 17:36:22', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('268', '82.81.204.24', 'Chrome', '17', '37', '2013-03-29 17:37:19', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('269', '82.81.204.24', 'Chrome', '17', '37', '2013-03-29 17:37:19', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('270', '82.81.204.24', 'Chrome', '17', '37', '2013-03-29 17:37:23', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('271', '82.81.204.24', 'Chrome', '17', '37', '2013-03-29 17:37:25', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('272', '82.81.204.24', 'Chrome', '17', '50', '2013-03-29 17:50:43', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('273', '82.81.204.24', 'Chrome', '17', '51', '2013-03-29 17:51:01', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('274', '82.81.204.24', 'Chrome', '17', '51', '2013-03-29 17:51:01', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('275', '82.81.204.24', 'Chrome', '17', '51', '2013-03-29 17:51:04', 'http://simplepanel.co.il/components/content/map.php', '/components/content/edit.php?aid=1');
INSERT INTO visitors_table VALUES ('276', '82.81.204.24', 'Chrome', '17', '51', '2013-03-29 17:51:14', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('277', '180.76.5.103', 'Firefox', '21', '4', '2013-03-29 21:04:41', '', '/robots.txt');
INSERT INTO visitors_table VALUES ('278', '79.181.67.5', 'Chrome', '10', '39', '2013-03-30 10:39:59', 'http://simple-webs.co.il/', '/');
INSERT INTO visitors_table VALUES ('279', '82.81.204.24', 'Chrome', '12', '9', '2013-03-30 12:09:13', '', '/');
INSERT INTO visitors_table VALUES ('280', '82.81.204.24', 'Chrome', '12', '9', '2013-03-30 12:09:17', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('281', '82.81.204.24', 'Chrome', '12', '9', '2013-03-30 12:09:46', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('282', '82.81.204.24', 'Chrome', '12', '11', '2013-03-30 12:11:29', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('283', '82.81.204.24', 'Chrome', '12', '16', '2013-03-30 12:16:40', 'http://simplepanel.co.il/index.php', '/media.html');
INSERT INTO visitors_table VALUES ('284', '82.81.204.24', 'Chrome', '12', '16', '2013-03-30 12:16:42', 'http://simplepanel.co.il/media.html', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('285', '82.81.204.24', 'Chrome', '12', '16', '2013-03-30 12:16:54', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('286', '82.81.204.24', 'Chrome', '12', '16', '2013-03-30 12:16:56', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('287', '82.81.204.24', 'Chrome', '12', '16', '2013-03-30 12:16:56', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('288', '82.81.204.24', 'Chrome', '12', '17', '2013-03-30 12:17:01', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('289', '82.81.204.24', 'Chrome', '12', '17', '2013-03-30 12:17:08', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('290', '82.81.204.24', 'Chrome', '12', '17', '2013-03-30 12:17:13', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('291', '82.81.204.24', 'Chrome', '13', '3', '2013-03-30 13:03:21', '', '/');
INSERT INTO visitors_table VALUES ('292', '82.81.204.24', 'Chrome', '13', '6', '2013-03-30 13:06:57', '', '/');
INSERT INTO visitors_table VALUES ('293', '82.81.204.24', 'Chrome', '13', '7', '2013-03-30 13:07:24', '', '/');
INSERT INTO visitors_table VALUES ('294', '82.81.204.24', 'Chrome', '13', '10', '2013-03-30 13:10:41', '', '/');
INSERT INTO visitors_table VALUES ('295', '82.81.204.24', 'Chrome', '13', '11', '2013-03-30 13:11:07', '', '/');
INSERT INTO visitors_table VALUES ('296', '82.81.204.24', 'Chrome', '13', '11', '2013-03-30 13:11:09', '', '/');
INSERT INTO visitors_table VALUES ('297', '82.81.204.24', 'Chrome', '13', '11', '2013-03-30 13:11:36', '', '/');
INSERT INTO visitors_table VALUES ('298', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:01', 'http://simplepanel.co.il/', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('299', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:01', 'http://simplepanel.co.il/', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('300', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:03', 'http://simplepanel.co.il/components/content/map.php', '/components/content/edit.php?aid=1');
INSERT INTO visitors_table VALUES ('301', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:07', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('302', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:49', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('303', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:53', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('304', '82.81.204.24', 'Chrome', '13', '15', '2013-03-30 13:15:59', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('305', '82.81.204.24', 'Chrome', '13', '16', '2013-03-30 13:16:22', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('306', '82.81.204.24', 'Chrome', '13', '16', '2013-03-30 13:16:50', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('307', '82.81.204.24', 'Chrome', '13', '17', '2013-03-30 13:17:10', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('308', '82.81.204.24', 'Chrome', '13', '17', '2013-03-30 13:17:39', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('309', '82.81.204.24', 'Chrome', '13', '17', '2013-03-30 13:17:58', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('310', '82.81.204.24', 'Chrome', '13', '20', '2013-03-30 13:20:16', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('311', '82.81.204.24', 'Chrome', '13', '20', '2013-03-30 13:20:47', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('312', '82.81.204.24', 'Chrome', '13', '21', '2013-03-30 13:21:04', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('313', '82.81.204.24', 'Chrome', '13', '21', '2013-03-30 13:21:27', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('314', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:08', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('315', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:30', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('316', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:34', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('317', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:34', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('318', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:35', 'http://simplepanel.co.il/components/content/map.php', '/components/content/edit.php?aid=1');
INSERT INTO visitors_table VALUES ('319', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:38', 'http://simplepanel.co.il/components/content/edit.php?aid=1', '/index.php');
INSERT INTO visitors_table VALUES ('320', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:43', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('321', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:43', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('322', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:55', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('323', '82.81.204.24', 'Chrome', '13', '24', '2013-03-30 13:24:55', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('324', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:00', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('325', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:00', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('326', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:02', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('327', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:10', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('328', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:10', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('329', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:17', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('330', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:17', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('331', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:23', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('332', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:23', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('333', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:25', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('334', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:25', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('335', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:42', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('336', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:51', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('337', '82.81.204.24', 'Chrome', '13', '25', '2013-03-30 13:25:53', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('338', '82.81.204.24', 'Chrome', '13', '28', '2013-03-30 13:28:39', '', '/index.php');
INSERT INTO visitors_table VALUES ('339', '82.81.204.24', 'Chrome', '13', '28', '2013-03-30 13:28:51', '', '/index.php');
INSERT INTO visitors_table VALUES ('340', '82.81.204.24', 'Chrome', '13', '30', '2013-03-30 13:30:59', '', '/index.php');
INSERT INTO visitors_table VALUES ('341', '82.81.204.24', 'Chrome', '13', '31', '2013-03-30 13:31:04', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('342', '82.81.204.24', 'Chrome', '13', '31', '2013-03-30 13:31:06', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('343', '82.81.204.24', 'Chrome', '13', '31', '2013-03-30 13:31:07', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('344', '82.81.204.24', 'Chrome', '13', '31', '2013-03-30 13:31:25', '', '/index.php');
INSERT INTO visitors_table VALUES ('345', '82.81.204.24', 'Chrome', '13', '34', '2013-03-30 13:34:01', '', '/index.php');
INSERT INTO visitors_table VALUES ('346', '82.81.204.24', 'Chrome', '13', '34', '2013-03-30 13:34:52', '', '/index.php');
INSERT INTO visitors_table VALUES ('347', '82.81.204.24', 'Chrome', '13', '35', '2013-03-30 13:35:41', '', '/index.php');
INSERT INTO visitors_table VALUES ('348', '82.81.204.24', 'Chrome', '13', '37', '2013-03-30 13:37:04', '', '/index.php');
INSERT INTO visitors_table VALUES ('349', '82.81.204.24', 'Chrome', '13', '38', '2013-03-30 13:38:48', '', '/index.php');
INSERT INTO visitors_table VALUES ('350', '82.81.204.24', 'Chrome', '13', '39', '2013-03-30 13:39:38', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('351', '82.81.204.24', 'Chrome', '13', '39', '2013-03-30 13:39:49', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('352', '82.81.204.24', 'Chrome', '13', '40', '2013-03-30 13:40:07', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('353', '82.81.204.24', 'Chrome', '13', '41', '2013-03-30 13:41:09', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('354', '82.81.204.24', 'Chrome', '13', '41', '2013-03-30 13:41:24', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('355', '82.81.204.24', 'Chrome', '13', '41', '2013-03-30 13:41:33', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('356', '82.81.204.24', 'Chrome', '13', '42', '2013-03-30 13:42:25', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('357', '82.81.204.24', 'Chrome', '13', '42', '2013-03-30 13:42:37', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('358', '82.81.204.24', 'Chrome', '13', '42', '2013-03-30 13:42:42', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('359', '82.81.204.24', 'Chrome', '13', '43', '2013-03-30 13:43:15', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('360', '82.81.204.24', 'Chrome', '13', '43', '2013-03-30 13:43:46', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('361', '82.81.204.24', 'Chrome', '13', '44', '2013-03-30 13:44:10', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('362', '82.81.204.24', 'Chrome', '13', '44', '2013-03-30 13:44:34', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('363', '82.81.204.24', 'Chrome', '13', '44', '2013-03-30 13:44:47', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('364', '82.81.204.24', 'Chrome', '13', '45', '2013-03-30 13:45:51', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('365', '82.81.204.24', 'Chrome', '13', '45', '2013-03-30 13:45:59', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('366', '82.81.204.24', 'Chrome', '13', '46', '2013-03-30 13:46:19', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('367', '82.81.204.24', 'Chrome', '13', '46', '2013-03-30 13:46:29', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('368', '82.81.204.24', 'Chrome', '13', '46', '2013-03-30 13:46:30', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('369', '82.81.204.24', 'Chrome', '13', '46', '2013-03-30 13:46:39', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('370', '82.81.204.24', 'Chrome', '13', '46', '2013-03-30 13:46:43', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('371', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:00', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('372', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:01', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('373', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:11', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('374', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:12', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('375', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:21', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('376', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:48', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('377', '82.81.204.24', 'Chrome', '13', '47', '2013-03-30 13:47:58', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('378', '82.81.204.24', 'Chrome', '13', '51', '2013-03-30 13:51:18', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('379', '82.81.204.24', 'Chrome', '13', '51', '2013-03-30 13:51:25', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('380', '82.81.204.24', 'Chrome', '13', '57', '2013-03-30 13:57:29', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('381', '82.81.204.24', 'Chrome', '13', '58', '2013-03-30 13:58:53', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('382', '82.81.204.24', 'Chrome', '13', '59', '2013-03-30 13:59:01', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('383', '82.81.204.24', 'Chrome', '14', '1', '2013-03-30 14:01:07', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('384', '82.81.204.24', 'Chrome', '14', '1', '2013-03-30 14:01:49', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('385', '85.64.194.79', 'MSIE', '15', '56', '2013-03-30 15:56:24', 'http://simple-webs.co.il/', '/');
INSERT INTO visitors_table VALUES ('386', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:01', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('387', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:04', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('388', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:06', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('389', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:07', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('390', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:23', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('391', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:46', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('392', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:53', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('393', '82.81.204.24', 'Chrome', '16', '35', '2013-03-30 16:35:58', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('394', '82.81.204.24', 'Chrome', '16', '36', '2013-03-30 16:36:02', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('395', '82.81.204.24', 'Chrome', '16', '36', '2013-03-30 16:36:03', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('396', '82.81.204.24', 'Chrome', '16', '38', '2013-03-30 16:38:31', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('397', '82.81.204.24', 'Chrome', '16', '38', '2013-03-30 16:38:37', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('398', '82.81.204.24', 'Chrome', '16', '39', '2013-03-30 16:39:39', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('399', '82.81.204.24', 'Chrome', '16', '39', '2013-03-30 16:39:40', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('400', '82.81.204.24', 'Chrome', '16', '40', '2013-03-30 16:40:21', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('401', '82.81.204.24', 'Chrome', '16', '45', '2013-03-30 16:45:44', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('402', '82.81.204.24', 'Chrome', '17', '12', '2013-03-30 17:12:34', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('403', '82.81.204.24', 'Chrome', '17', '12', '2013-03-30 17:12:43', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('404', '82.81.204.24', 'Chrome', '17', '13', '2013-03-30 17:13:56', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('405', '82.81.204.24', 'Chrome', '17', '14', '2013-03-30 17:14:08', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('406', '82.81.204.24', 'Chrome', '17', '14', '2013-03-30 17:14:47', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('407', '82.81.204.24', 'Chrome', '17', '15', '2013-03-30 17:15:51', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('408', '82.81.204.24', 'Chrome', '17', '17', '2013-03-30 17:17:44', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('409', '82.81.204.24', 'Chrome', '17', '18', '2013-03-30 17:18:52', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('410', '82.81.204.24', 'Chrome', '17', '20', '2013-03-30 17:20:31', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('471', '82.81.204.24', 'Chrome', '17', '47', '2013-03-30 17:47:57', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('472', '82.81.204.24', 'Chrome', '17', '48', '2013-03-30 17:48:08', '', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('473', '82.81.204.24', 'Chrome', '17', '48', '2013-03-30 17:48:09', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('474', '82.81.204.24', 'Chrome', '17', '48', '2013-03-30 17:48:10', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('475', '82.81.204.24', 'Chrome', '17', '48', '2013-03-30 17:48:13', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('476', '82.81.204.24', 'Chrome', '17', '48', '2013-03-30 17:48:20', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('477', '82.81.204.24', 'Chrome', '17', '48', '2013-03-30 17:48:21', 'http://simplepanel.co.il/components/users/edit.php?id=39', '/index.php');
INSERT INTO visitors_table VALUES ('478', '82.81.204.24', 'Chrome', '17', '49', '2013-03-30 17:49:13', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('479', '82.81.204.24', 'Chrome', '17', '49', '2013-03-30 17:49:27', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('480', '82.81.204.24', 'Chrome', '17', '50', '2013-03-30 17:50:20', '', '/index.php');
INSERT INTO visitors_table VALUES ('481', '82.81.204.24', 'Chrome', '17', '50', '2013-03-30 17:50:31', '', '/index.php');
INSERT INTO visitors_table VALUES ('482', '82.81.204.24', 'Chrome', '17', '50', '2013-03-30 17:50:42', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('483', '82.81.204.24', 'Chrome', '17', '50', '2013-03-30 17:50:45', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('484', '82.81.204.24', 'Chrome', '17', '51', '2013-03-30 17:51:05', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('485', '82.81.204.24', 'Chrome', '17', '51', '2013-03-30 17:51:37', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('486', '82.81.204.24', 'Chrome', '17', '51', '2013-03-30 17:51:41', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('487', '82.81.204.24', 'Chrome', '17', '52', '2013-03-30 17:52:02', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('488', '82.81.204.24', 'Chrome', '17', '52', '2013-03-30 17:52:07', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('489', '82.81.204.24', 'Chrome', '17', '52', '2013-03-30 17:52:39', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('490', '82.81.204.24', 'Chrome', '17', '52', '2013-03-30 17:52:50', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('491', '82.81.204.24', 'Chrome', '17', '54', '2013-03-30 17:54:13', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('492', '82.81.204.24', 'Chrome', '17', '54', '2013-03-30 17:54:25', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('493', '82.81.204.24', 'Chrome', '17', '57', '2013-03-30 17:57:58', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('494', '82.81.204.24', 'Chrome', '17', '58', '2013-03-30 17:58:04', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('495', '82.81.204.24', 'Chrome', '17', '58', '2013-03-30 17:58:18', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('496', '82.81.204.24', 'Chrome', '17', '58', '2013-03-30 17:58:27', '', '/components/users/edit.php?id=39');
INSERT INTO visitors_table VALUES ('497', '82.81.204.24', 'Chrome', '17', '58', '2013-03-30 17:58:45', 'http://simplepanel.co.il/components/users/edit.php?id=39', '/index.php');
INSERT INTO visitors_table VALUES ('498', '82.81.204.24', 'Chrome', '17', '59', '2013-03-30 17:59:38', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('499', '82.81.204.24', 'Chrome', '17', '59', '2013-03-30 17:59:43', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('500', '82.81.204.24', 'Chrome', '18', '1', '2013-03-30 18:01:31', '', '/index.php');
INSERT INTO visitors_table VALUES ('501', '82.81.204.24', 'Chrome', '18', '1', '2013-03-30 18:01:54', '', '/index.php');
INSERT INTO visitors_table VALUES ('502', '82.81.204.24', 'Chrome', '18', '2', '2013-03-30 18:02:01', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('503', '82.81.204.24', 'Chrome', '18', '3', '2013-03-30 18:03:46', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('504', '82.81.204.24', 'Chrome', '18', '3', '2013-03-30 18:03:56', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('505', '82.81.204.24', 'Chrome', '18', '4', '2013-03-30 18:04:23', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('506', '82.81.204.24', 'Chrome', '18', '4', '2013-03-30 18:04:27', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('507', '82.81.204.24', 'Chrome', '18', '6', '2013-03-30 18:06:46', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('508', '82.81.204.24', 'Chrome', '18', '9', '2013-03-30 18:09:31', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('509', '82.81.204.24', 'Chrome', '18', '9', '2013-03-30 18:09:40', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('510', '82.81.204.24', 'Chrome', '18', '9', '2013-03-30 18:09:44', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('511', '82.81.204.24', 'Chrome', '18', '9', '2013-03-30 18:09:54', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('512', '82.81.204.24', 'Chrome', '18', '11', '2013-03-30 18:11:14', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('513', '82.81.204.24', 'Chrome', '18', '11', '2013-03-30 18:11:24', '', '/index.php');
INSERT INTO visitors_table VALUES ('514', '82.81.204.24', 'Chrome', '18', '11', '2013-03-30 18:11:26', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('515', '82.81.204.24', 'Chrome', '18', '11', '2013-03-30 18:11:32', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('516', '82.81.204.24', 'Chrome', '18', '13', '2013-03-30 18:13:20', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('517', '66.249.73.218', '', '18', '15', '2013-03-30 18:15:33', '', '/robots.txt');
INSERT INTO visitors_table VALUES ('518', '66.249.73.218', '', '18', '15', '2013-03-30 18:15:34', '', '/');
INSERT INTO visitors_table VALUES ('519', '85.64.135.183', 'Chrome', '21', '40', '2013-03-30 21:40:10', '', '/');
INSERT INTO visitors_table VALUES ('520', '82.81.204.24', 'Safari', '22', '47', '2013-03-30 22:47:00', 'http://simple-webs.co.il/index.php', '/');
INSERT INTO visitors_table VALUES ('521', '82.81.204.24', 'Safari', '22', '47', '2013-03-30 22:47:14', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('522', '82.81.204.24', 'Safari', '22', '48', '2013-03-30 22:48:19', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('523', '82.81.204.24', 'Safari', '22', '48', '2013-03-30 22:48:19', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('524', '82.81.204.24', 'Safari', '22', '48', '2013-03-30 22:48:39', 'http://simplepanel.co.il/components/content/map.php', '/components/content/edit.php?aid=23');
INSERT INTO visitors_table VALUES ('525', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:00', 'http://simplepanel.co.il/components/content/edit.php?aid=23', '/index.php');
INSERT INTO visitors_table VALUES ('526', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:04', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('527', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:20', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('528', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:24', 'http://simplepanel.co.il/index.php', '/media.html');
INSERT INTO visitors_table VALUES ('529', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:26', 'http://simplepanel.co.il/media.html', '/log.php');
INSERT INTO visitors_table VALUES ('530', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:31', 'http://simplepanel.co.il/log.php', '/index.php');
INSERT INTO visitors_table VALUES ('531', '82.81.204.24', 'Safari', '22', '49', '2013-03-30 22:49:40', 'http://simplepanel.co.il/index.php', '/');
INSERT INTO visitors_table VALUES ('532', '217.132.113.251', 'Chrome', '22', '55', '2013-03-30 22:55:50', '', '/');
INSERT INTO visitors_table VALUES ('533', '66.249.73.218', '', '1', '49', '2013-03-31 01:49:07', '', '/robots.txt');
INSERT INTO visitors_table VALUES ('534', '66.249.73.218', '', '1', '49', '2013-03-31 01:49:08', '', '/index.php');
INSERT INTO visitors_table VALUES ('535', '173.242.125.206', '', '2', '33', '2013-03-31 02:33:46', '', '/robots.txt');
INSERT INTO visitors_table VALUES ('536', '173.242.125.206', '', '2', '33', '2013-03-31 02:33:48', '', '/');
INSERT INTO visitors_table VALUES ('537', '213.57.243.240', 'Chrome', '3', '36', '2013-03-31 03:36:28', '', '/');
INSERT INTO visitors_table VALUES ('538', '62.212.73.211', '', '9', '34', '2013-03-31 09:34:11', '', '/robots.txt');
INSERT INTO visitors_table VALUES ('539', '62.212.73.211', '', '9', '34', '2013-03-31 09:34:14', '', '/index.php');
INSERT INTO visitors_table VALUES ('540', '84.108.227.209', 'Chrome', '10', '14', '2013-03-31 10:14:50', '', '/');
INSERT INTO visitors_table VALUES ('541', '82.81.204.24', 'Chrome', '10', '45', '2013-03-31 10:45:37', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('542', '82.81.204.24', 'Chrome', '10', '45', '2013-03-31 10:45:47', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('543', '82.81.204.24', 'Chrome', '10', '49', '2013-03-31 10:49:01', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('544', '82.81.204.24', 'Chrome', '10', '49', '2013-03-31 10:49:34', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('545', '82.81.204.24', 'Chrome', '10', '49', '2013-03-31 10:49:34', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('546', '82.81.204.24', 'Chrome', '10', '49', '2013-03-31 10:49:43', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('547', '82.81.204.24', 'Chrome', '10', '50', '2013-03-31 10:50:18', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('548', '82.81.204.24', 'Chrome', '10', '50', '2013-03-31 10:50:20', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('549', '82.81.204.24', 'Chrome', '10', '50', '2013-03-31 10:50:21', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('550', '82.81.204.24', 'Chrome', '10', '51', '2013-03-31 10:51:13', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('551', '82.81.204.24', 'Chrome', '10', '51', '2013-03-31 10:51:19', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('552', '82.81.204.24', 'Chrome', '10', '58', '2013-03-31 10:58:48', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('553', '82.81.204.24', 'Chrome', '10', '58', '2013-03-31 10:58:54', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('554', '82.81.204.24', 'Chrome', '10', '59', '2013-03-31 10:59:03', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('555', '82.81.204.24', 'Chrome', '10', '59', '2013-03-31 10:59:20', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('556', '82.81.204.24', 'Chrome', '10', '59', '2013-03-31 10:59:56', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('557', '82.81.204.24', 'Chrome', '11', '0', '2013-03-31 11:00:11', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('558', '82.81.204.24', 'Chrome', '11', '0', '2013-03-31 11:00:28', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('559', '82.81.204.24', 'Chrome', '11', '0', '2013-03-31 11:00:55', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('560', '82.81.204.24', 'Chrome', '11', '1', '2013-03-31 11:01:33', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('561', '82.81.204.24', 'Chrome', '11', '1', '2013-03-31 11:01:48', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('562', '82.81.204.24', 'Chrome', '11', '2', '2013-03-31 11:02:00', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('563', '82.81.204.24', 'Chrome', '11', '3', '2013-03-31 11:03:05', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('564', '82.81.204.24', 'Chrome', '11', '3', '2013-03-31 11:03:28', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('565', '82.81.204.24', 'Chrome', '11', '3', '2013-03-31 11:03:37', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('566', '82.81.204.24', 'Chrome', '11', '4', '2013-03-31 11:04:46', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('567', '82.81.204.24', 'Chrome', '11', '6', '2013-03-31 11:06:04', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('568', '82.81.204.24', 'Chrome', '11', '6', '2013-03-31 11:06:17', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('569', '82.81.204.24', 'Chrome', '11', '6', '2013-03-31 11:06:31', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('570', '82.81.204.24', 'Chrome', '11', '6', '2013-03-31 11:06:46', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('571', '82.81.204.24', 'Chrome', '11', '7', '2013-03-31 11:07:31', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('572', '82.81.204.24', 'Chrome', '11', '8', '2013-03-31 11:08:22', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('573', '82.81.204.24', 'Chrome', '11', '9', '2013-03-31 11:09:20', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('574', '82.81.204.24', 'Chrome', '11', '9', '2013-03-31 11:09:58', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('575', '82.81.204.24', 'Chrome', '11', '10', '2013-03-31 11:10:28', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('576', '82.81.204.24', 'Chrome', '11', '10', '2013-03-31 11:10:55', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('577', '82.81.204.24', 'Chrome', '11', '11', '2013-03-31 11:11:14', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('578', '82.81.204.24', 'Chrome', '11', '11', '2013-03-31 11:11:38', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('579', '82.81.204.24', 'Chrome', '11', '11', '2013-03-31 11:11:46', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('580', '82.81.204.24', 'Chrome', '11', '12', '2013-03-31 11:12:12', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('581', '82.81.204.24', 'Chrome', '11', '12', '2013-03-31 11:12:28', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('582', '82.81.204.24', 'Chrome', '11', '12', '2013-03-31 11:12:51', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('583', '82.81.204.24', 'Chrome', '11', '13', '2013-03-31 11:13:06', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('584', '82.81.204.24', 'Chrome', '11', '13', '2013-03-31 11:13:13', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('585', '82.81.204.24', 'Chrome', '11', '13', '2013-03-31 11:13:18', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('586', '82.81.204.24', 'Chrome', '11', '13', '2013-03-31 11:13:27', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('587', '82.81.204.24', 'Chrome', '11', '13', '2013-03-31 11:13:41', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('588', '82.81.204.24', 'Chrome', '11', '13', '2013-03-31 11:13:52', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('589', '82.81.204.24', 'Chrome', '11', '14', '2013-03-31 11:14:24', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('590', '82.81.204.24', 'Chrome', '11', '14', '2013-03-31 11:14:32', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('591', '82.81.204.24', 'Chrome', '11', '14', '2013-03-31 11:14:48', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('592', '82.81.204.24', 'Chrome', '11', '14', '2013-03-31 11:14:59', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('593', '82.81.204.24', 'Chrome', '11', '15', '2013-03-31 11:15:01', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('594', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:39', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('595', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:41', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=');
INSERT INTO visitors_table VALUES ('596', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:44', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('597', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:49', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('598', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:50', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('599', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:53', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('600', '82.81.204.24', 'Chrome', '11', '17', '2013-03-31 11:17:57', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('601', '82.81.204.24', 'Chrome', '12', '35', '2013-03-31 12:35:55', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('602', '82.81.204.24', 'Chrome', '12', '35', '2013-03-31 12:35:59', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('603', '82.81.204.24', 'Chrome', '12', '37', '2013-03-31 12:37:14', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('604', '82.81.204.24', 'Safari', '12', '37', '2013-03-31 12:37:37', '', '/');
INSERT INTO visitors_table VALUES ('605', '82.81.204.24', 'Safari', '12', '37', '2013-03-31 12:37:46', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('606', '82.81.204.24', 'Chrome', '12', '40', '2013-03-31 12:40:11', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('607', '82.81.204.24', 'Chrome', '12', '44', '2013-03-31 12:44:10', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('608', '82.81.204.24', 'Chrome', '12', '44', '2013-03-31 12:44:59', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('609', '82.81.204.24', 'Chrome', '12', '45', '2013-03-31 12:45:19', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('610', '82.81.204.24', 'Chrome', '12', '45', '2013-03-31 12:45:20', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('611', '82.81.204.24', 'Chrome', '12', '48', '2013-03-31 12:48:07', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('612', '82.81.204.24', 'Chrome', '12', '48', '2013-03-31 12:48:26', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('613', '82.81.204.24', 'Chrome', '12', '50', '2013-03-31 12:50:14', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('614', '82.81.204.24', 'Chrome', '12', '51', '2013-03-31 12:51:24', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('615', '82.81.204.24', 'Chrome', '12', '52', '2013-03-31 12:52:38', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('616', '82.81.204.24', 'Chrome', '12', '52', '2013-03-31 12:52:42', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('617', '82.81.204.24', 'Chrome', '12', '52', '2013-03-31 12:52:48', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('618', '82.81.204.24', 'Chrome', '12', '54', '2013-03-31 12:54:01', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('619', '82.81.204.24', 'Chrome', '12', '54', '2013-03-31 12:54:14', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('620', '82.81.204.24', 'Chrome', '12', '54', '2013-03-31 12:54:17', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('621', '82.81.204.24', 'Chrome', '12', '56', '2013-03-31 12:56:05', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('622', '82.81.204.24', 'Chrome', '12', '57', '2013-03-31 12:57:02', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('623', '82.81.204.24', 'Chrome', '12', '57', '2013-03-31 12:57:17', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('624', '82.81.204.24', 'Chrome', '12', '57', '2013-03-31 12:57:20', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('625', '82.81.204.24', 'Chrome', '12', '59', '2013-03-31 12:59:15', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('626', '82.81.204.24', 'Chrome', '12', '59', '2013-03-31 12:59:45', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('627', '82.81.204.24', 'Chrome', '13', '0', '2013-03-31 13:00:32', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('628', '82.81.204.24', 'Chrome', '13', '6', '2013-03-31 13:06:47', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('629', '82.81.204.24', 'Chrome', '13', '7', '2013-03-31 13:07:37', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('630', '82.81.204.24', 'Chrome', '13', '8', '2013-03-31 13:08:02', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('631', '82.81.204.24', 'Chrome', '13', '8', '2013-03-31 13:08:35', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('632', '82.81.204.24', 'Chrome', '13', '9', '2013-03-31 13:09:15', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('633', '82.81.204.24', 'Chrome', '13', '9', '2013-03-31 13:09:49', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('634', '82.81.204.24', 'Chrome', '13', '10', '2013-03-31 13:10:15', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('635', '82.81.204.24', 'Chrome', '13', '10', '2013-03-31 13:10:33', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('636', '82.81.204.24', 'Chrome', '13', '11', '2013-03-31 13:11:06', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('637', '82.81.204.24', 'Chrome', '13', '11', '2013-03-31 13:11:43', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('638', '82.81.204.24', 'Chrome', '13', '12', '2013-03-31 13:12:48', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('639', '82.81.204.24', 'Chrome', '13', '13', '2013-03-31 13:13:03', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('640', '82.81.204.24', 'Chrome', '13', '13', '2013-03-31 13:13:06', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('641', '82.81.204.24', 'Chrome', '13', '13', '2013-03-31 13:13:43', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('642', '82.81.204.24', 'Chrome', '13', '13', '2013-03-31 13:13:53', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('643', '82.81.204.24', 'Chrome', '13', '14', '2013-03-31 13:14:19', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('644', '82.81.204.24', 'Chrome', '13', '14', '2013-03-31 13:14:43', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('645', '82.81.204.24', 'Chrome', '13', '15', '2013-03-31 13:15:20', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('646', '82.81.204.24', 'Chrome', '13', '16', '2013-03-31 13:16:11', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('647', '82.81.204.24', 'Chrome', '13', '19', '2013-03-31 13:19:24', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('648', '82.81.204.24', 'Chrome', '13', '20', '2013-03-31 13:20:07', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('649', '82.81.204.24', 'Chrome', '13', '32', '2013-03-31 13:32:50', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('650', '82.81.204.24', 'Chrome', '13', '32', '2013-03-31 13:32:52', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('651', '82.81.204.24', 'Chrome', '13', '33', '2013-03-31 13:33:05', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('652', '82.81.204.24', 'Chrome', '13', '35', '2013-03-31 13:35:11', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('653', '82.81.204.24', 'Chrome', '13', '37', '2013-03-31 13:37:09', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('654', '82.81.204.24', 'Chrome', '13', '38', '2013-03-31 13:38:04', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('655', '82.81.204.24', 'Chrome', '13', '38', '2013-03-31 13:38:10', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('656', '82.81.204.24', 'Chrome', '13', '38', '2013-03-31 13:38:12', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('657', '82.81.204.24', 'Chrome', '13', '38', '2013-03-31 13:38:22', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('658', '82.81.204.24', 'Chrome', '13', '38', '2013-03-31 13:38:28', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('659', '82.81.204.24', 'Chrome', '13', '38', '2013-03-31 13:38:35', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('660', '82.81.204.24', 'Chrome', '13', '40', '2013-03-31 13:40:02', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('661', '82.81.204.24', 'Chrome', '13', '40', '2013-03-31 13:40:18', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('662', '82.81.204.24', 'Chrome', '13', '40', '2013-03-31 13:40:20', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('663', '82.81.204.24', 'Chrome', '13', '46', '2013-03-31 13:46:04', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('664', '82.81.204.24', 'Chrome', '13', '46', '2013-03-31 13:46:15', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('665', '82.81.204.24', 'Chrome', '13', '46', '2013-03-31 13:46:35', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('666', '82.81.204.24', 'Chrome', '13', '47', '2013-03-31 13:47:07', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('667', '82.81.204.24', 'Chrome', '13', '47', '2013-03-31 13:47:22', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('668', '82.81.204.24', 'Chrome', '13', '47', '2013-03-31 13:47:37', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('669', '82.81.204.24', 'Chrome', '13', '48', '2013-03-31 13:48:14', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('670', '82.81.204.24', 'Chrome', '13', '48', '2013-03-31 13:48:47', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('671', '82.81.204.24', 'Chrome', '13', '49', '2013-03-31 13:49:23', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('672', '82.81.204.24', 'Chrome', '13', '49', '2013-03-31 13:49:52', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('673', '82.81.204.24', 'Chrome', '13', '49', '2013-03-31 13:49:54', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('674', '82.81.204.24', 'Chrome', '13', '50', '2013-03-31 13:50:02', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('675', '82.81.204.24', 'Chrome', '13', '50', '2013-03-31 13:50:24', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('676', '82.81.204.24', 'Chrome', '13', '50', '2013-03-31 13:50:41', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('677', '82.81.204.24', 'Chrome', '13', '51', '2013-03-31 13:51:21', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('678', '82.81.204.24', 'Chrome', '13', '51', '2013-03-31 13:51:28', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('679', '82.81.204.24', 'Chrome', '13', '51', '2013-03-31 13:51:32', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('680', '82.81.204.24', 'Chrome', '13', '53', '2013-03-31 13:53:24', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('681', '82.81.204.24', 'Chrome', '13', '53', '2013-03-31 13:53:28', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('682', '82.81.204.24', 'Chrome', '13', '53', '2013-03-31 13:53:39', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('683', '82.81.204.24', 'Chrome', '13', '53', '2013-03-31 13:53:51', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('684', '82.81.204.24', 'Chrome', '13', '54', '2013-03-31 13:54:00', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('685', '82.81.204.24', 'Chrome', '13', '54', '2013-03-31 13:54:14', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('686', '82.81.204.24', 'Chrome', '13', '54', '2013-03-31 13:54:52', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('687', '82.81.204.24', 'Chrome', '13', '55', '2013-03-31 13:55:22', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('688', '82.81.204.24', 'Chrome', '13', '55', '2013-03-31 13:55:33', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('689', '82.81.204.24', 'Chrome', '13', '55', '2013-03-31 13:55:38', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('690', '82.81.204.24', 'Chrome', '13', '56', '2013-03-31 13:56:41', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('691', '82.81.204.24', 'Chrome', '13', '57', '2013-03-31 13:57:31', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('692', '82.81.204.24', 'Chrome', '13', '57', '2013-03-31 13:57:46', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('693', '82.81.204.24', 'Chrome', '13', '59', '2013-03-31 13:59:09', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('694', '82.81.204.24', 'Chrome', '13', '59', '2013-03-31 13:59:15', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('695', '82.81.204.24', 'Chrome', '13', '59', '2013-03-31 13:59:26', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('696', '82.81.204.24', 'Chrome', '14', '1', '2013-03-31 14:01:34', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('697', '82.81.204.24', 'Chrome', '14', '1', '2013-03-31 14:01:40', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('698', '82.81.204.24', 'Chrome', '14', '1', '2013-03-31 14:01:47', '', '/components/users/edit.php?id=40');
INSERT INTO visitors_table VALUES ('699', '82.81.204.24', 'Chrome', '14', '1', '2013-03-31 14:01:48', 'http://simplepanel.co.il/components/users/edit.php?id=40', '/index.php');
INSERT INTO visitors_table VALUES ('700', '82.81.204.24', 'Chrome', '14', '1', '2013-03-31 14:01:52', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('701', '82.81.204.24', 'Chrome', '14', '3', '2013-03-31 14:03:02', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('702', '82.81.204.24', 'Chrome', '14', '3', '2013-03-31 14:03:15', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('703', '82.81.204.24', 'Chrome', '14', '3', '2013-03-31 14:03:23', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('704', '82.81.204.24', 'Chrome', '14', '3', '2013-03-31 14:03:25', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('705', '82.81.204.24', 'Chrome', '14', '3', '2013-03-31 14:03:36', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('706', '82.81.204.24', 'Chrome', '14', '6', '2013-03-31 14:06:43', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('707', '82.81.204.24', 'Chrome', '14', '6', '2013-03-31 14:06:51', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('708', '82.81.204.24', 'Chrome', '14', '6', '2013-03-31 14:06:53', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('709', '82.81.204.24', 'Chrome', '14', '6', '2013-03-31 14:06:56', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('710', '82.81.204.24', 'Chrome', '14', '7', '2013-03-31 14:07:02', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('711', '82.81.204.24', 'Chrome', '14', '7', '2013-03-31 14:07:03', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('712', '82.81.204.24', 'Chrome', '14', '7', '2013-03-31 14:07:28', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('713', '82.81.204.24', 'Chrome', '14', '7', '2013-03-31 14:07:32', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('714', '82.81.204.24', 'Chrome', '14', '7', '2013-03-31 14:07:45', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('715', '82.81.204.24', 'Chrome', '14', '7', '2013-03-31 14:07:47', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('716', '82.81.204.24', 'Chrome', '14', '8', '2013-03-31 14:08:10', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('717', '82.81.204.24', 'Chrome', '14', '8', '2013-03-31 14:08:12', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('718', '82.81.204.24', 'Chrome', '14', '12', '2013-03-31 14:12:49', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('719', '82.81.204.24', 'Chrome', '14', '13', '2013-03-31 14:13:02', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('720', '82.81.204.24', 'Chrome', '14', '13', '2013-03-31 14:13:03', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('721', '82.81.204.24', 'Chrome', '14', '13', '2013-03-31 14:13:14', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('722', '82.81.204.24', 'Chrome', '14', '13', '2013-03-31 14:13:16', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('723', '82.81.204.24', 'Chrome', '14', '13', '2013-03-31 14:13:29', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('724', '82.81.204.24', 'Chrome', '14', '15', '2013-03-31 14:15:49', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('725', '82.81.204.24', 'Chrome', '14', '16', '2013-03-31 14:16:09', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('726', '82.81.204.24', 'Chrome', '14', '16', '2013-03-31 14:16:10', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('727', '82.81.204.24', 'Chrome', '14', '17', '2013-03-31 14:17:28', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('728', '82.81.204.24', 'Chrome', '14', '17', '2013-03-31 14:17:32', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('729', '82.81.204.24', 'Chrome', '14', '17', '2013-03-31 14:17:58', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('730', '82.81.204.24', 'Chrome', '14', '18', '2013-03-31 14:18:04', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('731', '82.81.204.24', 'Chrome', '14', '18', '2013-03-31 14:18:41', '', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('732', '82.81.204.24', 'Chrome', '14', '18', '2013-03-31 14:18:49', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('733', '82.81.204.24', 'Chrome', '14', '18', '2013-03-31 14:18:58', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('734', '82.81.204.24', 'Chrome', '14', '19', '2013-03-31 14:19:13', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('735', '82.81.204.24', 'Chrome', '14', '19', '2013-03-31 14:19:14', 'http://simplepanel.co.il/components/users/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('736', '82.81.204.24', 'Chrome', '14', '19', '2013-03-31 14:19:30', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('737', '82.81.204.24', 'Chrome', '14', '33', '2013-03-31 14:33:29', '', '/index.php');
INSERT INTO visitors_table VALUES ('738', '82.81.204.24', 'Chrome', '14', '35', '2013-03-31 14:35:29', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('739', '82.81.204.24', 'Chrome', '14', '35', '2013-03-31 14:35:29', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('740', '82.81.204.24', 'Chrome', '14', '35', '2013-03-31 14:35:44', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('741', '82.81.204.24', 'Chrome', '14', '35', '2013-03-31 14:35:44', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('742', '82.81.204.24', 'Chrome', '14', '36', '2013-03-31 14:36:20', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('743', '82.81.204.24', 'Chrome', '14', '36', '2013-03-31 14:36:20', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('744', '82.81.204.24', 'Chrome', '14', '36', '2013-03-31 14:36:30', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('745', '82.81.204.24', 'Chrome', '14', '36', '2013-03-31 14:36:30', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('746', '82.81.204.24', 'Chrome', '14', '37', '2013-03-31 14:37:16', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('747', '82.81.204.24', 'Chrome', '14', '37', '2013-03-31 14:37:16', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('748', '82.81.204.24', 'Chrome', '14', '37', '2013-03-31 14:37:53', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('749', '82.81.204.24', 'Chrome', '14', '37', '2013-03-31 14:37:53', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('750', '82.81.204.24', 'Chrome', '14', '38', '2013-03-31 14:38:08', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('751', '82.81.204.24', 'Chrome', '14', '38', '2013-03-31 14:38:08', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('752', '82.81.204.24', 'Chrome', '14', '39', '2013-03-31 14:39:15', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('753', '82.81.204.24', 'Chrome', '14', '39', '2013-03-31 14:39:15', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('754', '82.81.204.24', 'Chrome', '14', '39', '2013-03-31 14:39:22', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('755', '82.81.204.24', 'Chrome', '14', '39', '2013-03-31 14:39:22', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('756', '82.81.204.24', 'Chrome', '14', '39', '2013-03-31 14:39:56', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('757', '82.81.204.24', 'Chrome', '14', '39', '2013-03-31 14:39:56', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('758', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:06', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('759', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:06', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('760', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:21', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('761', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:21', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('762', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:22', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('763', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:22', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('764', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:39', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('765', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:39', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('766', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:57', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('767', '82.81.204.24', 'Chrome', '14', '40', '2013-03-31 14:40:57', '', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('768', '82.81.204.24', 'Chrome', '14', '41', '2013-03-31 14:41:42', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('769', '82.81.204.24', 'Chrome', '14', '41', '2013-03-31 14:41:47', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('770', '82.81.204.24', 'Chrome', '14', '42', '2013-03-31 14:42:09', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('771', '82.81.204.24', 'Chrome', '14', '42', '2013-03-31 14:42:14', 'http://simplepanel.co.il/index.php', '/index.html');
INSERT INTO visitors_table VALUES ('772', '82.81.204.24', 'Chrome', '14', '42', '2013-03-31 14:42:30', 'http://simplepanel.co.il/index.html', '/log.php');
INSERT INTO visitors_table VALUES ('773', '82.81.204.24', 'Chrome', '14', '42', '2013-03-31 14:42:34', 'http://simplepanel.co.il/log.php', '/index.php');
INSERT INTO visitors_table VALUES ('774', '82.81.204.24', 'Chrome', '14', '42', '2013-03-31 14:42:35', 'http://simplepanel.co.il/index.php', '/media.html');
INSERT INTO visitors_table VALUES ('775', '82.81.204.24', 'Chrome', '14', '57', '2013-03-31 14:57:35', 'http://simplepanel.co.il/media.html', '/index.php');
INSERT INTO visitors_table VALUES ('776', '82.81.204.24', 'Chrome', '14', '57', '2013-03-31 14:57:39', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('777', '82.81.204.24', 'Chrome', '14', '57', '2013-03-31 14:57:42', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=1');
INSERT INTO visitors_table VALUES ('778', '82.81.204.24', 'Chrome', '14', '57', '2013-03-31 14:57:44', 'http://simplepanel.co.il/components/users/edit.php?id=1', '/index.php');
INSERT INTO visitors_table VALUES ('779', '82.81.204.24', 'Chrome', '14', '57', '2013-03-31 14:57:45', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('780', '82.81.204.24', 'Chrome', '14', '58', '2013-03-31 14:58:01', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('781', '82.81.204.24', 'Chrome', '14', '58', '2013-03-31 14:58:04', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('782', '82.81.204.24', 'Chrome', '14', '58', '2013-03-31 14:58:04', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('783', '82.81.204.24', 'Chrome', '14', '59', '2013-03-31 14:59:14', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('784', '82.81.204.24', 'Chrome', '15', '1', '2013-03-31 15:01:21', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('785', '82.81.204.24', 'Chrome', '15', '1', '2013-03-31 15:01:40', 'http://simplepanel.co.il/index.php', '/');
INSERT INTO visitors_table VALUES ('786', '109.64.64.105', 'Chrome', '15', '1', '2013-03-31 15:01:40', 'http://www.facebook.com/l.php?u=http%3A%2F%2Fsimplepanel.co.il%2F&h=tAQGnVzVu', '/');
INSERT INTO visitors_table VALUES ('787', '82.81.204.24', 'Chrome', '15', '1', '2013-03-31 15:01:46', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('788', '109.64.64.105', 'Chrome', '15', '2', '2013-03-31 15:02:39', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('789', '109.64.64.105', 'Chrome', '15', '4', '2013-03-31 15:04:37', 'http://simplepanel.co.il/index.php', '/index.html');
INSERT INTO visitors_table VALUES ('790', '109.64.64.105', 'Chrome', '15', '4', '2013-03-31 15:04:55', 'http://simplepanel.co.il/index.html', '/ui-elements.html');
INSERT INTO visitors_table VALUES ('791', '109.64.64.105', 'Chrome', '15', '4', '2013-03-31 15:04:59', 'http://simplepanel.co.il/ui-elements.html', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('792', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:09', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('793', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:09', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('794', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:11', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('795', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:11', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('796', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:17', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('797', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:56', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('798', '82.81.204.24', 'Chrome', '15', '5', '2013-03-31 15:05:57', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('799', '109.64.64.105', 'Chrome', '15', '6', '2013-03-31 15:06:53', 'http://simplepanel.co.il/ui-elements.html', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('800', '109.64.64.105', 'Chrome', '15', '11', '2013-03-31 15:11:42', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('801', '109.64.64.105', 'Chrome', '15', '11', '2013-03-31 15:11:51', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('802', '109.64.64.105', 'Chrome', '15', '11', '2013-03-31 15:11:51', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('803', '109.64.64.105', 'Chrome', '15', '12', '2013-03-31 15:12:02', 'http://simplepanel.co.il/components/content/map.php', '/components/content/edit.php?aid=21');
INSERT INTO visitors_table VALUES ('804', '109.64.64.105', 'Chrome', '15', '12', '2013-03-31 15:12:05', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('805', '109.64.64.105', 'Chrome', '15', '12', '2013-03-31 15:12:05', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('806', '109.64.64.105', 'Chrome', '15', '15', '2013-03-31 15:15:11', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('807', '109.64.64.105', 'Chrome', '15', '15', '2013-03-31 15:15:17', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('808', '109.64.64.105', 'Chrome', '15', '21', '2013-03-31 15:21:13', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('809', '109.64.64.105', 'Chrome', '15', '21', '2013-03-31 15:21:19', 'http://simplepanel.co.il/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('810', '109.64.64.105', 'Chrome', '15', '23', '2013-03-31 15:23:43', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('811', '109.64.64.105', 'Chrome', '15', '29', '2013-03-31 15:29:39', 'http://simplepanel.co.il/components/users/index.php', '/components/users/edit.php?id=41');
INSERT INTO visitors_table VALUES ('812', '109.64.64.105', 'Chrome', '15', '29', '2013-03-31 15:29:49', 'http://simplepanel.co.il/components/users/edit.php?id=41', '/index.php');
INSERT INTO visitors_table VALUES ('813', '109.64.64.105', 'Chrome', '16', '1', '2013-03-31 16:01:18', 'http://simplepanel.co.il/components/users/edit.php?id=41', '/index.php');
INSERT INTO visitors_table VALUES ('814', '82.81.204.24', 'Chrome', '16', '48', '2013-03-31 16:48:17', '', '/');
INSERT INTO visitors_table VALUES ('815', '82.81.204.24', 'Chrome', '16', '48', '2013-03-31 16:48:35', 'http://simplepanel.co.il/', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('816', '82.81.204.24', 'Chrome', '16', '48', '2013-03-31 16:48:50', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('817', '82.81.204.24', 'Chrome', '16', '48', '2013-03-31 16:48:57', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('818', '82.81.204.24', 'Chrome', '16', '50', '2013-03-31 16:50:22', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('819', '82.81.204.24', 'Chrome', '16', '50', '2013-03-31 16:50:44', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('820', '82.81.204.24', 'Chrome', '16', '50', '2013-03-31 16:50:50', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('821', '82.81.204.24', 'Chrome', '16', '50', '2013-03-31 16:50:58', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('822', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:10', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('823', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:31', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('824', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:48', 'http://simplepanel.co.il/index.php', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('825', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:49', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('826', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:51', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('827', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:55', 'http://simplepanel.co.il/components/statistics/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('828', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:56', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('829', '82.81.204.24', 'Chrome', '16', '51', '2013-03-31 16:51:56', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('830', '82.81.204.24', 'Chrome', '16', '52', '2013-03-31 16:52:06', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('831', '82.81.204.24', 'Chrome', '16', '52', '2013-03-31 16:52:06', 'http://simplepanel.co.il/components/content/map.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('832', '82.81.204.24', 'Chrome', '16', '52', '2013-03-31 16:52:23', 'http://simplepanel.co.il/components/content/map.php', '/index.php');
INSERT INTO visitors_table VALUES ('833', '82.81.204.24', 'Chrome', '16', '54', '2013-03-31 16:54:57', 'http://simplepanel.co.il/index.php', '/components/statistics/index.php');
INSERT INTO visitors_table VALUES ('834', '82.81.204.24', 'Chrome', '16', '55', '2013-03-31 16:55:01', '', '/components/services/');
INSERT INTO visitors_table VALUES ('835', '82.81.204.24', 'Chrome', '16', '55', '2013-03-31 16:55:31', 'http://simplepanel.co.il/components/services/', '/index.php');
INSERT INTO visitors_table VALUES ('836', '82.81.204.24', 'Chrome', '16', '55', '2013-03-31 16:55:41', 'http://simplepanel.co.il/components/services/', '/index.php');
INSERT INTO visitors_table VALUES ('837', '82.81.204.24', 'Chrome', '16', '55', '2013-03-31 16:55:41', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('838', '82.81.204.24', 'Chrome', '16', '56', '2013-03-31 16:56:16', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('839', '82.81.204.24', 'Chrome', '16', '56', '2013-03-31 16:56:32', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('840', '82.81.204.24', 'Chrome', '16', '57', '2013-03-31 16:57:30', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('841', '82.81.204.24', 'Chrome', '16', '58', '2013-03-31 16:58:06', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('842', '82.81.204.24', 'Chrome', '16', '58', '2013-03-31 16:58:27', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('843', '82.81.204.24', 'Chrome', '16', '58', '2013-03-31 16:58:46', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('844', '82.81.204.24', 'Chrome', '16', '59', '2013-03-31 16:59:01', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('845', '82.81.204.24', 'Chrome', '16', '59', '2013-03-31 16:59:16', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('846', '82.81.204.24', 'Chrome', '16', '59', '2013-03-31 16:59:47', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('847', '82.81.204.24', 'Chrome', '16', '59', '2013-03-31 16:59:59', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('848', '82.81.204.24', 'Chrome', '17', '0', '2013-03-31 17:00:13', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('849', '82.81.204.24', 'Chrome', '17', '0', '2013-03-31 17:00:57', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('850', '82.81.204.24', 'Chrome', '17', '1', '2013-03-31 17:01:24', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('851', '82.81.204.24', 'Chrome', '17', '1', '2013-03-31 17:01:56', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('852', '82.81.204.24', 'Chrome', '17', '2', '2013-03-31 17:02:15', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('853', '82.81.204.24', 'Chrome', '17', '3', '2013-03-31 17:03:02', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('854', '82.81.204.24', 'Chrome', '17', '3', '2013-03-31 17:03:11', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('855', '82.81.204.24', 'Chrome', '17', '4', '2013-03-31 17:04:00', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('856', '82.81.204.24', 'Chrome', '17', '4', '2013-03-31 17:04:36', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('857', '82.81.204.24', 'Chrome', '17', '4', '2013-03-31 17:04:55', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('858', '82.81.204.24', 'Chrome', '17', '5', '2013-03-31 17:05:10', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('859', '82.81.204.24', 'Chrome', '17', '5', '2013-03-31 17:05:29', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('860', '82.81.204.24', 'Chrome', '17', '5', '2013-03-31 17:05:51', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('861', '82.81.204.24', 'Chrome', '17', '5', '2013-03-31 17:05:52', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('862', '82.81.204.24', 'Chrome', '17', '5', '2013-03-31 17:05:57', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('863', '82.81.204.24', 'Chrome', '17', '6', '2013-03-31 17:06:34', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('864', '82.81.204.24', 'Chrome', '17', '7', '2013-03-31 17:07:25', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('865', '82.81.204.24', 'Chrome', '17', '10', '2013-03-31 17:10:21', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('866', '82.81.204.24', 'Chrome', '17', '10', '2013-03-31 17:10:39', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('867', '82.81.204.24', 'Chrome', '17', '11', '2013-03-31 17:11:27', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('868', '82.81.204.24', 'Chrome', '17', '11', '2013-03-31 17:11:28', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('869', '82.81.204.24', 'Chrome', '17', '12', '2013-03-31 17:12:11', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('870', '82.81.204.24', 'Chrome', '17', '12', '2013-03-31 17:12:18', '', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('871', '82.81.204.24', 'Chrome', '17', '24', '2013-03-31 17:24:33', 'http://simple-webs.co.il/features.html', '/');
INSERT INTO visitors_table VALUES ('872', '82.81.204.24', 'Chrome', '17', '25', '2013-03-31 17:25:04', 'http://simplepanel.co.il/', '/components/users/index.php');
INSERT INTO visitors_table VALUES ('873', '82.81.204.24', 'Chrome', '17', '29', '2013-03-31 17:29:17', 'http://simplepanel.co.il/components/users/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('874', '82.81.204.24', 'Chrome', '17', '29', '2013-03-31 17:29:20', 'http://simplepanel.co.il/index.php', '/components/services/index.php');
INSERT INTO visitors_table VALUES ('875', '82.81.204.24', 'Chrome', '17', '29', '2013-03-31 17:29:51', 'http://simplepanel.co.il/components/services/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('876', '82.81.204.24', 'Chrome', '17', '29', '2013-03-31 17:29:55', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('877', '82.81.204.24', 'Chrome', '17', '29', '2013-03-31 17:29:58', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('878', '82.81.204.24', 'Chrome', '17', '30', '2013-03-31 17:30:02', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('879', '82.81.204.24', 'Chrome', '17', '39', '2013-03-31 17:39:00', 'http://simple-webs.co.il/index.php', '/');
INSERT INTO visitors_table VALUES ('880', '82.81.204.24', 'Chrome', '17', '39', '2013-03-31 17:39:05', 'http://simplepanel.co.il/', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('881', '82.81.33.174', 'Chrome', '20', '11', '2013-03-31 20:11:03', '', '/components/backup/');
INSERT INTO visitors_table VALUES ('882', '82.81.33.174', 'Chrome', '20', '11', '2013-03-31 20:11:07', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('883', '82.81.33.174', 'Chrome', '20', '11', '2013-03-31 20:11:08', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('884', '82.81.33.174', 'Chrome', '20', '11', '2013-03-31 20:11:08', 'http://simplepanel.co.il/index.php', '/components/content/map.php');
INSERT INTO visitors_table VALUES ('885', '82.81.33.174', 'Chrome', '20', '11', '2013-03-31 20:11:09', 'http://simplepanel.co.il/login.php', '/index.php');
INSERT INTO visitors_table VALUES ('886', '82.81.33.174', 'Chrome', '20', '11', '2013-03-31 20:11:11', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('887', '82.81.33.174', 'Chrome', '20', '16', '2013-03-31 20:16:10', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('888', '82.81.33.174', 'Chrome', '20', '16', '2013-03-31 20:16:51', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('889', '82.81.33.174', 'Chrome', '20', '17', '2013-03-31 20:17:22', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('890', '82.81.33.174', 'Chrome', '20', '17', '2013-03-31 20:17:47', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('891', '82.81.33.174', 'Chrome', '20', '23', '2013-03-31 20:23:13', '', '/components/backup/');
INSERT INTO visitors_table VALUES ('892', '82.81.33.174', 'Chrome', '20', '27', '2013-03-31 20:27:21', '', '/components/backup/');
INSERT INTO visitors_table VALUES ('893', '82.81.33.174', 'Chrome', '20', '27', '2013-03-31 20:27:44', 'http://simplepanel.co.il/components/backup/', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('894', '82.81.33.174', 'Chrome', '20', '27', '2013-03-31 20:27:46', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('895', '82.81.33.174', 'Chrome', '20', '27', '2013-03-31 20:27:56', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('896', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:03', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('897', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:07', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('898', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:08', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('899', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:12', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('900', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:14', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('901', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:27', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('902', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:28', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('903', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:37', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('904', '82.81.33.174', 'Chrome', '20', '28', '2013-03-31 20:28:47', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('905', '82.81.33.174', 'Chrome', '20', '29', '2013-03-31 20:29:06', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('906', '82.81.33.174', 'Chrome', '20', '29', '2013-03-31 20:29:13', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('907', '82.81.33.174', 'Chrome', '20', '29', '2013-03-31 20:29:24', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('908', '82.81.33.174', 'Chrome', '20', '29', '2013-03-31 20:29:27', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('909', '82.81.33.174', 'Chrome', '20', '31', '2013-03-31 20:31:56', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('910', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:23', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('911', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:25', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('912', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:32', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('913', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:34', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('914', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:37', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('915', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:38', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('916', '82.81.33.174', 'Chrome', '20', '35', '2013-03-31 20:35:51', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('917', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:00', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('918', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:08', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('919', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:10', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('920', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:11', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('921', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:14', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('922', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:16', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('923', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:54', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('924', '82.81.33.174', 'Chrome', '20', '36', '2013-03-31 20:36:56', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('925', '82.81.33.174', 'Chrome', '20', '37', '2013-03-31 20:37:04', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('926', '82.81.33.174', 'Chrome', '20', '37', '2013-03-31 20:37:59', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('927', '82.81.33.174', 'Chrome', '20', '38', '2013-03-31 20:38:54', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('928', '82.81.33.174', 'Chrome', '20', '38', '2013-03-31 20:38:58', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('929', '82.81.33.174', 'Chrome', '20', '39', '2013-03-31 20:39:30', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('930', '82.81.33.174', 'Chrome', '20', '39', '2013-03-31 20:39:34', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('931', '82.81.33.174', 'Chrome', '20', '39', '2013-03-31 20:39:46', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('932', '82.81.33.174', 'Chrome', '20', '40', '2013-03-31 20:40:57', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('933', '82.81.33.174', 'Chrome', '20', '40', '2013-03-31 20:40:59', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('934', '82.81.33.174', 'Chrome', '20', '41', '2013-03-31 20:41:33', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('935', '82.81.33.174', 'Chrome', '20', '44', '2013-03-31 20:44:42', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('936', '82.81.33.174', 'Chrome', '20', '46', '2013-03-31 20:46:34', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('937', '82.81.33.174', 'Chrome', '20', '46', '2013-03-31 20:46:38', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('938', '82.81.33.174', 'Chrome', '20', '46', '2013-03-31 20:46:54', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('939', '82.81.33.174', 'Chrome', '20', '47', '2013-03-31 20:47:07', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('940', '82.81.33.174', 'Chrome', '20', '47', '2013-03-31 20:47:21', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('941', '82.81.33.174', 'Chrome', '20', '49', '2013-03-31 20:49:16', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('942', '82.81.33.174', 'Chrome', '20', '49', '2013-03-31 20:49:39', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('943', '82.81.33.174', 'Chrome', '20', '50', '2013-03-31 20:50:50', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('944', '82.81.33.174', 'Chrome', '20', '52', '2013-03-31 20:52:24', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('945', '82.81.33.174', 'Chrome', '20', '52', '2013-03-31 20:52:35', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('946', '82.81.33.174', 'Chrome', '20', '52', '2013-03-31 20:52:52', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('947', '82.81.33.174', 'Chrome', '20', '53', '2013-03-31 20:53:20', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('948', '82.81.33.174', 'Chrome', '20', '53', '2013-03-31 20:53:54', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('949', '82.81.33.174', 'Chrome', '20', '55', '2013-03-31 20:55:03', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('950', '82.81.33.174', 'Chrome', '20', '55', '2013-03-31 20:55:54', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('951', '82.81.33.174', 'Chrome', '20', '56', '2013-03-31 20:56:08', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('952', '82.81.33.174', 'Chrome', '20', '56', '2013-03-31 20:56:22', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('953', '82.81.33.174', 'Chrome', '20', '57', '2013-03-31 20:57:00', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('954', '82.81.33.174', 'Chrome', '20', '57', '2013-03-31 20:57:32', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('955', '82.81.33.174', 'Chrome', '20', '58', '2013-03-31 20:58:16', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('956', '82.81.33.174', 'Chrome', '20', '58', '2013-03-31 20:58:44', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('957', '82.81.33.174', 'Chrome', '20', '59', '2013-03-31 20:59:47', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('958', '82.81.33.174', 'Chrome', '20', '59', '2013-03-31 20:59:59', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('959', '82.81.33.174', 'Chrome', '21', '0', '2013-03-31 21:00:34', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('960', '82.81.33.174', 'Chrome', '21', '1', '2013-03-31 21:01:14', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('961', '82.81.33.174', 'Chrome', '21', '1', '2013-03-31 21:01:54', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('962', '82.81.33.174', 'Chrome', '21', '2', '2013-03-31 21:02:28', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('963', '82.81.33.174', 'Chrome', '21', '3', '2013-03-31 21:03:00', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('964', '82.81.33.174', 'Chrome', '21', '3', '2013-03-31 21:03:56', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('965', '82.81.33.174', 'Chrome', '21', '4', '2013-03-31 21:04:22', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('966', '82.81.33.174', 'Chrome', '21', '4', '2013-03-31 21:04:42', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('967', '82.81.33.174', 'Chrome', '21', '5', '2013-03-31 21:05:45', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('968', '82.81.33.174', 'Chrome', '21', '5', '2013-03-31 21:05:53', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('969', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:02', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('970', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:20', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('971', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:33', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('972', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:36', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('973', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:53', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('974', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:57', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('975', '82.81.33.174', 'Chrome', '21', '6', '2013-03-31 21:06:58', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('976', '82.81.33.174', 'Chrome', '21', '7', '2013-03-31 21:07:53', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('977', '82.81.33.174', 'Chrome', '21', '8', '2013-03-31 21:08:19', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('978', '82.81.33.174', 'Chrome', '21', '8', '2013-03-31 21:08:34', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('979', '82.81.33.174', 'Chrome', '21', '11', '2013-03-31 21:11:14', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('980', '82.81.33.174', 'Chrome', '21', '12', '2013-03-31 21:12:52', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('981', '82.81.33.174', 'Chrome', '21', '13', '2013-03-31 21:13:14', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('982', '82.81.33.174', 'Chrome', '21', '13', '2013-03-31 21:13:15', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('983', '82.81.33.174', 'Chrome', '21', '15', '2013-03-31 21:15:09', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('984', '82.81.33.174', 'Chrome', '21', '24', '2013-03-31 21:24:25', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('985', '82.81.33.174', 'Chrome', '21', '24', '2013-03-31 21:24:28', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('986', '82.81.33.174', 'Chrome', '21', '24', '2013-03-31 21:24:40', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('987', '82.81.33.174', 'Chrome', '21', '24', '2013-03-31 21:24:50', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('988', '82.81.33.174', 'Chrome', '21', '25', '2013-03-31 21:25:16', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('989', '82.81.33.174', 'Chrome', '21', '25', '2013-03-31 21:25:17', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('990', '82.81.33.174', 'Chrome', '21', '25', '2013-03-31 21:25:20', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('991', '82.81.33.174', 'Chrome', '21', '25', '2013-03-31 21:25:35', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('992', '82.81.33.174', 'Chrome', '21', '25', '2013-03-31 21:25:42', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('993', '82.81.33.174', 'Chrome', '21', '25', '2013-03-31 21:25:45', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('994', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:08', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('995', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:11', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('996', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:14', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('997', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:24', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('998', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:27', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('999', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:43', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1000', '82.81.33.174', 'Chrome', '21', '26', '2013-03-31 21:26:53', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1001', '82.81.33.174', 'Chrome', '21', '27', '2013-03-31 21:27:20', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1002', '82.81.33.174', 'Chrome', '21', '27', '2013-03-31 21:27:23', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1003', '82.81.33.174', 'Chrome', '21', '27', '2013-03-31 21:27:23', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1004', '82.81.33.174', 'Chrome', '21', '27', '2013-03-31 21:27:28', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1005', '82.81.33.174', 'Chrome', '21', '27', '2013-03-31 21:27:35', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1006', '82.81.33.174', 'Chrome', '21', '27', '2013-03-31 21:27:39', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1007', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:03', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1008', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:18', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1009', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:29', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1010', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:32', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1011', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:37', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1012', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:39', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1013', '82.81.33.174', 'Chrome', '21', '28', '2013-03-31 21:28:56', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1014', '82.81.33.174', 'Chrome', '21', '31', '2013-03-31 21:31:01', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1015', '82.81.33.174', 'Chrome', '21', '31', '2013-03-31 21:31:11', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1016', '82.81.33.174', 'Chrome', '21', '31', '2013-03-31 21:31:22', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1017', '82.81.33.174', 'Chrome', '21', '31', '2013-03-31 21:31:27', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1018', '82.81.33.174', 'Chrome', '21', '31', '2013-03-31 21:31:28', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1019', '82.81.33.174', 'Chrome', '21', '32', '2013-03-31 21:32:26', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1020', '82.81.33.174', 'Chrome', '21', '32', '2013-03-31 21:32:37', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1021', '82.81.33.174', 'Chrome', '21', '32', '2013-03-31 21:32:41', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1022', '82.81.33.174', 'Chrome', '21', '34', '2013-03-31 21:34:41', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1023', '82.81.33.174', 'Chrome', '21', '34', '2013-03-31 21:34:52', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1024', '82.81.33.174', 'Chrome', '21', '34', '2013-03-31 21:34:54', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('1025', '82.81.33.174', 'Chrome', '21', '35', '2013-03-31 21:35:59', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1026', '82.81.33.174', 'Chrome', '21', '36', '2013-03-31 21:36:03', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1027', '82.81.33.174', 'Chrome', '21', '36', '2013-03-31 21:36:04', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('1028', '82.81.33.174', 'Chrome', '21', '36', '2013-03-31 21:36:08', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1029', '82.81.33.174', 'Chrome', '21', '36', '2013-03-31 21:36:18', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1030', '82.81.33.174', 'Chrome', '21', '36', '2013-03-31 21:36:20', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('1031', '82.81.33.174', 'Chrome', '21', '39', '2013-03-31 21:39:27', '', '/index.php');
INSERT INTO visitors_table VALUES ('1032', '82.81.33.174', 'Chrome', '21', '39', '2013-03-31 21:39:28', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1033', '82.81.33.174', 'Chrome', '21', '39', '2013-03-31 21:39:49', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1034', '82.81.33.174', 'Chrome', '21', '39', '2013-03-31 21:39:51', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1035', '82.81.33.174', 'Chrome', '21', '40', '2013-03-31 21:40:13', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1036', '82.81.33.174', 'Chrome', '21', '41', '2013-03-31 21:41:07', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1037', '82.81.33.174', 'Chrome', '21', '41', '2013-03-31 21:41:14', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1038', '82.81.33.174', 'Chrome', '21', '41', '2013-03-31 21:41:35', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1039', '82.81.33.174', 'Chrome', '21', '41', '2013-03-31 21:41:48', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1040', '82.81.33.174', 'Chrome', '21', '42', '2013-03-31 21:42:09', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1041', '82.81.33.174', 'Chrome', '21', '42', '2013-03-31 21:42:18', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1042', '82.81.33.174', 'Chrome', '21', '42', '2013-03-31 21:42:24', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1043', '82.81.33.174', 'Chrome', '21', '42', '2013-03-31 21:42:38', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1044', '82.81.33.174', 'Chrome', '21', '42', '2013-03-31 21:42:42', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('1045', '82.81.33.174', 'Chrome', '21', '42', '2013-03-31 21:42:55', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1046', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:20', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1047', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:26', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1048', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:40', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1049', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:47', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1050', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:49', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1051', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:52', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('1052', '82.81.33.174', 'Chrome', '21', '43', '2013-03-31 21:43:56', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1053', '82.81.33.174', 'Chrome', '21', '44', '2013-03-31 21:44:39', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1054', '82.81.33.174', 'Chrome', '21', '44', '2013-03-31 21:44:42', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1055', '82.81.33.174', 'Chrome', '21', '45', '2013-03-31 21:45:01', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1056', '82.81.33.174', 'Chrome', '21', '45', '2013-03-31 21:45:03', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1057', '82.81.33.174', 'Chrome', '21', '45', '2013-03-31 21:45:05', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1058', '82.81.33.174', 'Chrome', '21', '45', '2013-03-31 21:45:06', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1059', '82.81.33.174', 'Chrome', '21', '45', '2013-03-31 21:45:08', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1060', '82.81.33.174', 'Chrome', '21', '45', '2013-03-31 21:45:51', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1061', '82.81.33.174', 'Chrome', '21', '46', '2013-03-31 21:46:02', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1062', '82.81.33.174', 'Chrome', '21', '46', '2013-03-31 21:46:03', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1063', '82.81.33.174', 'Chrome', '21', '46', '2013-03-31 21:46:07', 'http://simplepanel.co.il/components/backup/index.php', '/index.php');
INSERT INTO visitors_table VALUES ('1064', '82.81.33.174', 'Chrome', '21', '46', '2013-03-31 21:46:10', 'http://simplepanel.co.il/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1065', '82.81.33.174', 'Chrome', '21', '49', '2013-03-31 21:49:15', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1066', '82.81.33.174', 'Chrome', '21', '49', '2013-03-31 21:49:43', '', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1067', '82.81.33.174', 'Chrome', '21', '49', '2013-03-31 21:49:44', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1068', '82.81.33.174', 'Chrome', '21', '49', '2013-03-31 21:49:47', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1069', '82.81.33.174', 'Chrome', '21', '49', '2013-03-31 21:49:49', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1070', '82.81.33.174', 'Chrome', '21', '50', '2013-03-31 21:50:04', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');
INSERT INTO visitors_table VALUES ('1071', '82.81.33.174', 'Chrome', '21', '50', '2013-03-31 21:50:06', 'http://simplepanel.co.il/components/backup/index.php', '/components/backup/index.php');


